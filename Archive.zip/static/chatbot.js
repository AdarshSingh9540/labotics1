const chatbotToggler = document.querySelector(".chatbot-toggler")
chatbotToggler.addEventListener("click",() =>
    document.body.classList.toggle("show-chatbot"))
sendchatbtn.addEventListener("click", handlechat);