

// const login =document.querySelector('.login-box')

window.addEventListener("load", function () {
    const elementloginbox = document.querySelector(".login-box");
        elementloginbox.classList.add("zoom-in");
});